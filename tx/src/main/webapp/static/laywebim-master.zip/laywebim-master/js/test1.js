﻿var base= {
    name: "base",
    getInfo: function() {
        return this.name;
    },
    getMoreInfo: function() {
        return this.id + ":" + this.name;
    }
}

var ext1 = {
    id: 0,
    name:"ext1"

}